package fxml;
	
import java.util.Date;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;


public class FxmlMain extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			 // Đọc file fxml và vẽ giao diện.
	         Parent root = FXMLLoader.load(getClass()
	                   .getResource("MyScene.fxml"));
			
			// Thêm layout vào Scene
			Scene scene = new Scene(root);
			
			// Thêm Scene vào Stage
			primaryStage.setScene(scene);
			
			// Hiển thị Stage
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
