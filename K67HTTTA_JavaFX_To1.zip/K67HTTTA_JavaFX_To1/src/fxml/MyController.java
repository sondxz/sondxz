package fxml;

import java.util.Date;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class MyController {
	@FXML
	private TextField tf;
	
	@FXML
	public void showDateTime() {
		// Nội dung xử lý khi bấm nút "Xem ngày giờ"
		tf.setText(new Date().toString());
	}
	
}
