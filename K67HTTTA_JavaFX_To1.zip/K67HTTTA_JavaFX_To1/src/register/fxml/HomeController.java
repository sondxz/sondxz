package register.fxml;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class HomeController implements Initializable{
	
	@FXML
	private TableView<User> userListTV;
	
	@FXML
	private TableColumn<User, String> usernameCol;
	
	@FXML
	private TableColumn<User, String> fullnameCol;
	@FXML
	private TextField emailTF;
	@FXML
	private TextField fullnameTF;
	@FXML
	private Label welcomeMsg;
	@FXML
	private ImageView imgView;
	
	private User loginedUser;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// Nội dung khi mở màn hình Home
		Platform.runLater(()->{
			welcomeMsg.setText("Xin chào " + loginedUser.getFullname());
		});
		
		
		// Bat cap
		usernameCol.setCellValueFactory(new PropertyValueFactory<User,
				String>("email"));

		fullnameCol.setCellValueFactory(
				new PropertyValueFactory<User, String>("fullname"));
		
		// Lấy ds User từ CSDL
		List<User> listUser = UserDAO.listAllUser();
		ObservableList<User> obsList =	FXCollections.observableArrayList(listUser);
		// Đưa vào bảng tableview
		userListTV.setItems(obsList);
	}
	
	@FXML
	public void onClickRow() {
		User selectedUser = userListTV.getSelectionModel().getSelectedItem();
		emailTF.setText(selectedUser.getEmail());
		fullnameTF.setText(selectedUser.getFullname());
		// Dua anh vao ImageView
		FileInputStream input;
		try {
			if(selectedUser.getImgPath()!=null) {
				input = new FileInputStream(selectedUser.getImgPath());
				Image image = new Image(input);
				imgView.setImage(image);
			}else {
				imgView.setImage(null);
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@FXML
	public void onClickExit() {
		welcomeMsg.getScene().getWindow().hide();
	}

	public User getLoginedUser() {
		return loginedUser;
	}

	public void setLoginedUser(User loginedUser) {
		this.loginedUser = loginedUser;
	}
	
	
}
