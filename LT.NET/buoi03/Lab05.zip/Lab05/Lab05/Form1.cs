﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace Lab05
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // chuoi ket noi
        string strCon = @"Data Source=M01;Initial Catalog=QLSV;Integrated Security=True";

        // doi tuong ket noi
        SqlConnection sqlCon = null;

        // ham mo ket noi
        private void MoKetNoi()
        {
            if (sqlCon == null) sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed) sqlCon.Open();
        }

        // ham hien thi danh sach sinh vien
        private void HienThiDS_SinhVien()
        {
            MoKetNoi();

            // doi tuong truy van
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = "select * from tblSinhVien";

            // gan vao ket noi
            sqlCmd.Connection = sqlCon;

            // thuc thi truy van
            SqlDataReader reader = sqlCmd.ExecuteReader();
            lsvDanhSach.Items.Clear();
            while(reader.Read())
            {
                // doc du lieu tu csdl
                string maSV = reader.GetString(0).Trim();
                string tenSV = reader.GetString(1).Trim();
                string gioiTinh = reader.GetString(2).Trim();
                string ngaySinh = reader.GetDateTime(3).ToString("MM/dd/yyyy");
                string queQuan = reader.GetString(4).Trim();
                string maLop = reader.GetString(5).Trim();

                // tao 1 dong moi
                ListViewItem lvi = new ListViewItem(maSV);
                lvi.SubItems.Add(tenSV);
                lvi.SubItems.Add(gioiTinh);
                lvi.SubItems.Add(ngaySinh);
                lvi.SubItems.Add(queQuan);
                lvi.SubItems.Add(maLop);

                // gan dong moi vao listview
                lsvDanhSach.Items.Add(lvi);
            }
            reader.Close();
        }

        // ham tim kiem theo ma
        private void TimKiemTheoMa(string maSV)
        {
            MoKetNoi();

            // doi tuong truy van
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = "select * from tblSinhVien where MaSV = '" + maSV + "'";

            // gan vao ket noi
            sqlCmd.Connection = sqlCon;

            // thuc thi truy van
            SqlDataReader reader = sqlCmd.ExecuteReader();
            lsvDanhSach.Items.Clear();
            if (reader.Read())
            {
                // doc du lieu tu csdl
                string _maSV = reader.GetString(0).Trim();
                string tenSV = reader.GetString(1).Trim();
                string gioiTinh = reader.GetString(2).Trim();
                string ngaySinh = reader.GetDateTime(3).ToString("MM/dd/yyyy");
                string queQuan = reader.GetString(4).Trim();
                string maLop = reader.GetString(5).Trim();

                // tao 1 dong moi
                ListViewItem lvi = new ListViewItem(maSV);
                lvi.SubItems.Add(tenSV);
                lvi.SubItems.Add(gioiTinh);
                lvi.SubItems.Add(ngaySinh);
                lvi.SubItems.Add(queQuan);
                lvi.SubItems.Add(maLop);

                // gan dong moi vao listview
                lsvDanhSach.Items.Add(lvi);
            }
            reader.Close();
        }

        // ham tim kiem theo ma
        private void TimKiemTheoTen(string tenSV)
        {
            MoKetNoi();

            // doi tuong truy van
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.CommandText = "select * from tblSinhVien where TenSV LIKE '%"+tenSV+"%'";

            // gan vao ket noi
            sqlCmd.Connection = sqlCon;

            // thuc thi truy van
            SqlDataReader reader = sqlCmd.ExecuteReader();
            lsvDanhSach.Items.Clear();
            while (reader.Read())
            {
                // doc du lieu tu csdl
                string maSV = reader.GetString(0).Trim();
                string _tenSV = reader.GetString(1).Trim();
                string gioiTinh = reader.GetString(2).Trim();
                string ngaySinh = reader.GetDateTime(3).ToString("MM/dd/yyyy");
                string queQuan = reader.GetString(4).Trim();
                string maLop = reader.GetString(5).Trim();

                // tao 1 dong moi
                ListViewItem lvi = new ListViewItem(maSV);
                lvi.SubItems.Add(_tenSV);
                lvi.SubItems.Add(gioiTinh);
                lvi.SubItems.Add(ngaySinh);
                lvi.SubItems.Add(queQuan);
                lvi.SubItems.Add(maLop);

                // gan dong moi vao listview
                lsvDanhSach.Items.Add(lvi);
            }
            reader.Close();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có thực sự muốn thoát hay không?",
                "Hộp thoại",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);
            if (result == DialogResult.Yes) Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            HienThiDS_SinhVien();

            btnSua.Enabled = false;
            btnXoa.Enabled = false;
            groupBox2.Enabled = false;
        }

        private void btnTimkiem_Click(object sender, EventArgs e)
        {
            // lay du lieu tu fomr
            string maSV = txtTkMaSV.Text.Trim();
            string tenSV = txtTkTenSV.Text.Trim();

            // phan chia truong hop
            if (maSV != "" && tenSV == "")
                TimKiemTheoMa(maSV);
            else if (maSV == "" && tenSV != "")
                TimKiemTheoTen(tenSV);
            else if(maSV!="" && tenSV!="")
                TimKiemTheoMa(maSV);
            else
            {
                MessageBox.Show("Bạn chưa nhập dữ liệu cần tìm!");
                txtTkMaSV.Focus();
            }
        }
    }
}
