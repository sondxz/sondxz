﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_05
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void btn_thoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("bạn có thực sự muốn thoát", "Hộp thoại",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if(result == DialogResult.Yes)
            {
                Close();
            }

        }
        private string constring = @"Data Source=M09;Initial Catalog=QLSV;Integrated Security=True";
        SqlConnection sqlcon = null;

        private void MoKetNoi()
        {
            if(sqlcon == null)
            {
                sqlcon = new SqlConnection(constring);
            }

            if(sqlcon.State == ConnectionState.Closed) 
            {
                sqlcon.Open();
            }
        }

        private void HienThiDS_SinhVien()
        {
            MoKetNoi();

            SqlCommand sqlcmd = new SqlCommand();
            sqlcmd.CommandType = CommandType.Text;
            sqlcmd.CommandText = "select * from Sinhvien";

            //gan vao ket noi
            sqlcmd.Connection = sqlcon;

            //thuc thi truy van
            SqlDataReader data = sqlcmd.ExecuteReader();
            lsv_dsSinhVien.Items.Clear();
            while (data.Read())
            {
                //doc du lieu tu csdl
                string masv = data.GetString(0).Trim();
                string tensv = data.GetString(1).Trim();
                string gioitinh = data.GetString(2).Trim();
                string ngaysinh = data.GetDateTime(3).ToString("MM/dd/yyyy");
                string quequan = data.GetString(4).Trim();
                string malop = data.GetString(5).Trim();

                //tao 1 dong moi
                ListViewItem lvi = new ListViewItem(masv);
                lvi.SubItems.Add(tensv);
                lvi.SubItems.Add(gioitinh);
                lvi.SubItems.Add(ngaysinh);
                lvi.SubItems.Add(quequan);
                lvi.SubItems.Add(malop);

                //gan mot dong vao listview
                lsv_dsSinhVien.Items.Add(lvi);
            }
            data.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btn_sua.Enabled = false;
            btn_xoa.Enabled = false;
            groupBox3.Enabled = false;
            HienThiDS_SinhVien();
        }

        private void btn_Timkiem_Click(object sender, EventArgs e)
        {
            string masv = txt_Tkmasv.Text.Trim();
            string tensv = txt_Tktensv.Text.Trim();
            if(masv != "" && tensv == "")
            {
                TimKiemTheoMaSV(masv);
            }
            else if(masv == "" && tensv != "")
            {
                TimKiemTheoTenSV(tensv);
            }
            else if (masv != "" && tensv != "") 
            {
                TimKiemTheoMaSV(masv);
            }
            else
            {
                MessageBox.Show("Bạn chưa nhập dữ liệu tìm kiếm!","", MessageBoxButtons.OK);
                txt_Tkmasv.Focus();
            }
        }

        private void TimKiemTheoMaSV(string masv)
        {
            MoKetNoi();

            SqlCommand sqlcmd = new SqlCommand();
            sqlcmd.CommandType = CommandType.Text;
            sqlcmd.CommandText = "select * from Sinhvien where masv = '" + masv + " '";

            //gan vao ket noi
            sqlcmd.Connection = sqlcon;

            //thuc thi truy van
            SqlDataReader data = sqlcmd.ExecuteReader();
            lsv_dsSinhVien.Items.Clear();
            while (data.Read())
            {
                //doc du lieu tu csdl
                string _masv = data.GetString(0).Trim();
                string tensv = data.GetString(1).Trim();
                string gioitinh = data.GetString(2).Trim();
                string ngaysinh = data.GetDateTime(3).ToString("MM/dd/yyyy");
                string quequan = data.GetString(4).Trim();
                string malop = data.GetString(5).Trim();

                //tao 1 dong moi
                ListViewItem lvi = new ListViewItem(masv);
                lvi.SubItems.Add(tensv);
                lvi.SubItems.Add(gioitinh);
                lvi.SubItems.Add(ngaysinh);
                lvi.SubItems.Add(quequan);
                lvi.SubItems.Add(malop);

                //gan mot dong vao listview
                lsv_dsSinhVien.Items.Add(lvi);
            }
            data.Close();
        }

        private void TimKiemTheoTenSV(string tensv)
        {
            MoKetNoi();

            SqlCommand sqlcmd = new SqlCommand();
            sqlcmd.CommandType = CommandType.Text;
            sqlcmd.CommandText = "select * from Sinhvien where tensv like '%"+tensv+"%'";

            //gan vao ket noi
            sqlcmd.Connection = sqlcon;

            //thuc thi truy van
            SqlDataReader data = sqlcmd.ExecuteReader();
            lsv_dsSinhVien.Items.Clear();
            while (data.Read())
            {
                //doc du lieu tu csdl
                string masv = data.GetString(0).Trim();
                string _tensv = data.GetString(1).Trim();
                string gioitinh = data.GetString(2).Trim();
                string ngaysinh = data.GetDateTime(3).ToString("MM/dd/yyyy");
                string quequan = data.GetString(4).Trim();
                string malop = data.GetString(5).Trim();

                //tao 1 dong moi
                ListViewItem lvi = new ListViewItem(masv);
                lvi.SubItems.Add(_tensv);
                lvi.SubItems.Add(gioitinh);
                lvi.SubItems.Add(ngaysinh);
                lvi.SubItems.Add(quequan);
                lvi.SubItems.Add(malop);

                //gan mot dong vao listview
                lsv_dsSinhVien.Items.Add(lvi);
            }
            data.Close();
        }
    }
}
