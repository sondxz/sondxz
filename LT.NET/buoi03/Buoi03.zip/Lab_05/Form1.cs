﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_05
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void btn_thoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có thực sự muốn thoát", "Hộp thoại",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if(result == DialogResult.Yes)
            {
                Close();
            }

        }
        private string constring = @"Data Source=M09;Initial Catalog=QLY_SINHVIEN;Integrated Security=True";
        SqlConnection sqlcon = null;

        private void MoKetNoi()
        {
            if(sqlcon == null)
            {
                sqlcon = new SqlConnection(constring);
            }

            if(sqlcon.State == ConnectionState.Closed) 
            {
                sqlcon.Open();
            }
        }

        private void HienThiDS_SinhVien()
        {
            MoKetNoi();

            SqlCommand sqlcmd = new SqlCommand();
            sqlcmd.CommandType = CommandType.Text;
            sqlcmd.CommandText = "select * from SV";

            //gan vao ket noi
            sqlcmd.Connection = sqlcon;

            //thuc thi truy van
            SqlDataReader data = sqlcmd.ExecuteReader();
            lsv_dsSinhVien.Items.Clear();
            while (data.Read())
            {
                //doc du lieu tu csdl
                string masv = data.GetString(0).Trim();
                string tensv = data.GetString(1).Trim();
                string gioitinh = data.GetString(2).Trim();
                string ngaysinh = data.GetDateTime(3).ToString("MM/dd/yyyy");
                string quequan = data.GetString(4).Trim();
                string malop = data.GetString(5).Trim();

                //tao 1 dong moi
                ListViewItem lvi = new ListViewItem(masv);
                lvi.SubItems.Add(tensv);
                lvi.SubItems.Add(gioitinh);
                lvi.SubItems.Add(ngaysinh);
                lvi.SubItems.Add(quequan);
                lvi.SubItems.Add(malop);

                //gan mot dong vao listview
                lsv_dsSinhVien.Items.Add(lvi);
            }
            data.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btn_sua.Enabled = false;
            btn_xoa.Enabled = false;
            groupBox3.Enabled = false;
            HienThiDS_SinhVien();

            cb_gioitinh.Items.Add("Nam");
            cb_gioitinh.Items.Add("Nữ");
        }

        private void btn_Timkiem_Click(object sender, EventArgs e)
        {
            string masv = txt_Tkmasv.Text.Trim();
            string tensv = txt_Tktensv.Text.Trim();
            if(masv != "" && tensv == "")
            {
                TimKiemTheoMaSV(masv);
            }
            else if(masv == "" && tensv != "")
            {
                TimKiemTheoTenSV(tensv);
            }
            else if (masv != "" && tensv != "") 
            {
                TimKiemTheoMaSV(masv);
            }
            else
            {
                MessageBox.Show("Bạn chưa nhập dữ liệu tìm kiếm!","", MessageBoxButtons.OK);
                txt_Tkmasv.Focus();
            }
        }

        private void TimKiemTheoMaSV(string masv)
        {
            MoKetNoi();

            SqlCommand sqlcmd = new SqlCommand();
            sqlcmd.CommandType = CommandType.Text;
            sqlcmd.CommandText = "select * from SV where masv = '" + masv + " '";

            //gan vao ket noi
            sqlcmd.Connection = sqlcon;

            //thuc thi truy van
            SqlDataReader data = sqlcmd.ExecuteReader();
            lsv_dsSinhVien.Items.Clear();
            while (data.Read())
            {
                //doc du lieu tu csdl
                string _masv = data.GetString(0).Trim();
                string tensv = data.GetString(1).Trim();
                string gioitinh = data.GetString(2).Trim();
                string ngaysinh = data.GetDateTime(3).ToString("MM/dd/yyyy");
                string quequan = data.GetString(4).Trim();
                string malop = data.GetString(5).Trim();

                //tao 1 dong moi
                ListViewItem lvi = new ListViewItem(masv);
                lvi.SubItems.Add(tensv);
                lvi.SubItems.Add(gioitinh);
                lvi.SubItems.Add(ngaysinh);
                lvi.SubItems.Add(quequan);
                lvi.SubItems.Add(malop);

                //gan mot dong vao listview
                lsv_dsSinhVien.Items.Add(lvi);
            }
            data.Close();
        }

        private void TimKiemTheoTenSV(string tensv)
        {
            MoKetNoi();

            SqlCommand sqlcmd = new SqlCommand();
            sqlcmd.CommandType = CommandType.Text;
            sqlcmd.CommandText = "select * from SV where tensv like N'%"+tensv+"%'";

            //gan vao ket noi
            sqlcmd.Connection = sqlcon;

            //thuc thi truy van
            SqlDataReader data = sqlcmd.ExecuteReader();
            lsv_dsSinhVien.Items.Clear();
            while (data.Read())
            {
                //doc du lieu tu csdl
                string masv = data.GetString(0).Trim();
                string _tensv = data.GetString(1).Trim();
                string gioitinh = data.GetString(2).Trim();
                string ngaysinh = data.GetDateTime(3).ToString("MM/dd/yyyy");
                string quequan = data.GetString(4).Trim();
                string malop = data.GetString(5).Trim();

                //tao 1 dong moi
                ListViewItem lvi = new ListViewItem(masv);
                lvi.SubItems.Add(_tensv);
                lvi.SubItems.Add(gioitinh);
                lvi.SubItems.Add(ngaysinh);
                lvi.SubItems.Add(quequan);
                lvi.SubItems.Add(malop);

                //gan mot dong vao listview
                lsv_dsSinhVien.Items.Add(lvi);
            }
            data.Close();

            


        }
        //phan loai nut luu
            int chucnang = 0;    

        //Them SinhVien
        private void ThemSV()
        {
            try 
            {
                string maSV = txt_masv.Text;
                string tenSV = txt_tensv.Text;
                string gioitinh = "";
                if(cb_gioitinh.SelectedIndex == 0) { gioitinh = "Nam"; }
                else if(cb_gioitinh.SelectedIndex == 1) { gioitinh = "Nữ"; }
                string ngaysinh = dtp_ngaysinh.Value.Year + "/" + dtp_ngaysinh.Value.Month + "/" + dtp_ngaysinh.Value.Day;
                string quequan = txt_quequan.Text;
                string malop = txt_malop.Text;

                //Mo ket noi
                MoKetNoi();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into SV values('"+txt_masv.Text+"',N'"+txt_tensv.Text+"',N'"+cb_gioitinh.Text+"',convert(datetime,'"+dtp_ngaysinh.Text+"',111),N'"+txt_quequan.Text+"','"+txt_malop.Text+"')";

                cmd.Connection = sqlcon;
                int kq = cmd.ExecuteNonQuery();
                if(kq > 0) 
                {
                    MessageBox.Show("Bạn đã thêm thành công! ");
                    HienThiDS_SinhVien();
                    XoaDLForm();              
                }
                else
                {
                    MessageBox.Show("Bạn đã thêm không thành công! ");
                    XoaDLForm();
                }
            }
            catch(Exception ex) 
            {
                MessageBox.Show("Lỗi ở đây: " + ex.ToString());        
            }
            
        }

        private void XoaDLForm() 
        {
            txt_masv.Clear();
            txt_tensv.Clear();
            txt_quequan.Clear();
            txt_malop.Clear();
            cb_gioitinh.ResetText();
        }

        //SUA SINH VIEN
        private void SuaSV()
        {
            try
            {
                string maSV = txt_masv.Text;
                string tenSV = txt_tensv.Text;
                string gioitinh = "";
                if (cb_gioitinh.SelectedIndex == 0) { gioitinh = "Nam"; }
                else if (cb_gioitinh.SelectedIndex == 1) { gioitinh = "Nữ"; }
                string ngaysinh = dtp_ngaysinh.Value.Year + "/" + dtp_ngaysinh.Value.Month + "/" + dtp_ngaysinh.Value.Day;
                string quequan = txt_quequan.Text;
                string malop = txt_malop.Text;

                //Mo ket noi
                MoKetNoi();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update SV set MaSV = '"+txt_masv.Text+"', TenSV = N'"+txt_tensv.Text+"', GioiTinh = N'"+cb_gioitinh.Text+"', NgaySinh = CONVERT(datetime,'"+dtp_ngaysinh.Text+"',111), QueQuan = N'"+txt_quequan.Text +"', MaLop = N'"+txt_malop.Text +"' where MaSV = '"+txt_masv.Text +"'";

                cmd.Connection = sqlcon;
                int kq = cmd.ExecuteNonQuery();
                if (kq > 0)
                {
                    MessageBox.Show("Bạn đã sửa thành công! ");
                    HienThiDS_SinhVien();
                    XoaDLForm();
                }
                else
                {
                    MessageBox.Show("Bạn đã sửa không thành công! ");
                    XoaDLForm();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi ở đây: " + ex.ToString());
            }
            btn_sua.Enabled = false;
            btn_xoa.Enabled = false;
        }

        //khai bao xoa
        string maSV_xoa = " ";

        //xoa sinhvien
        private void XoaSV()
        {
            try
            {
                maSV_xoa = txt_masv.Text;
                //Mo ket noi
                MoKetNoi();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete SV where MaSV = '" + maSV_xoa + "'";

                cmd.Connection = sqlcon;
                int kq = cmd.ExecuteNonQuery();
                if (kq > 0)
                {
                    MessageBox.Show("Bạn đã xóa thành công! ");
                    HienThiDS_SinhVien();
                    XoaDLForm();
                }
                else
                {
                    MessageBox.Show("Bạn đã xóa không thành công! ");
                    XoaDLForm();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi ở đây: " + ex.ToString());
            }
            btn_sua.Enabled = false;
            btn_xoa.Enabled = false;
        }


        private void btn_luu_Click(object sender, EventArgs e)
        {
            
            if(chucnang == 1)
            {
                ThemSV();
            }
            else if(chucnang == 2)
            {
                SuaSV();
            }
        }

        private void btn_Them_Click(object sender, EventArgs e)
        {
            chucnang = 1;
            groupBox3.Enabled = true;
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            chucnang = 2;
            groupBox3.Enabled = true;
        }

        private void lsv_dsSinhVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            btn_sua.Enabled = true;
            btn_xoa.Enabled = true;

            //aaaa
            if (lsv_dsSinhVien.SelectedItems.Count == 0) return;

            //fill du lieu
            ListViewItem lvi = lsv_dsSinhVien.SelectedItems[0];
            txt_masv.Text = lvi.SubItems[0].Text;
            txt_tensv.Text = lvi.SubItems[1].Text;

            if (lvi.SubItems[2].Text == "Nam") cb_gioitinh.SelectedIndex = 0;
            else cb_gioitinh.SelectedIndex = 1;

            string[] ns = lvi.SubItems[3].Text.Split('/');
            dtp_ngaysinh.Value = new DateTime(int.Parse(ns[2]), int.Parse(ns[0]), int.Parse(ns[1]));
            txt_quequan.Text = lvi.SubItems[4].Text;
            txt_malop.Text = lvi.SubItems[5].Text;
        }

        private void btn_xoa_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có thực sự muốn xóa không?", "Cảnh báo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning); ;
            if(result == DialogResult.Yes)
            {
                XoaSV();
            }
            
        }
    }
}
