﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_07
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string strCon = @"Data Source=M09;Initial Catalog=Qly_sinhVien;Integrated Security=True";
        SqlConnection sqlCon = null;

        DataSet ds = null;
        SqlDataAdapter adapter = null;

        //Ham mo ket noi
        private void MoKetNoi() 
        {
            if(sqlCon== null) sqlCon= new SqlConnection(strCon); 
            if(sqlCon.State == ConnectionState.Closed) sqlCon.Open();
        }

        //Ham hien thi danh sach
        private void HienThiDanhSach()
        {
            MoKetNoi();

            //lenh truy van
            string sql = "select * from tbl_SinhVien";
            adapter = new SqlDataAdapter(sql, sqlCon);
            SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
            ds = new DataSet();
            adapter.Fill(ds, "tbl_SinhVien");
            dgv_danhsach.DataSource = ds.Tables["tbl_SinhVien"];
        }

        //Timkiem theo ma sv
        private void TimKiemMaSV( string maSV)
        {
            MoKetNoi();

            //lenh truy van
            string sql = "select * from tbl_SinhVien where MaSV = '" + maSV + "'";
            adapter = new SqlDataAdapter(sql, sqlCon);
            SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
            ds = new DataSet();
            adapter.Fill(ds, "tbl_TKMaSV");
            dgv_danhsach.DataSource = ds.Tables["tbl_TKMaSV"];
        }
        private void TimKiemTenSV(string tenSV)
        {
            MoKetNoi();

            //lenh truy van
            string sql = "select * from tbl_SinhVien where TenSV like N'%" + tenSV + "%'";
            adapter = new SqlDataAdapter(sql, sqlCon);
            SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
            ds = new DataSet();
            adapter.Fill(ds, "tbl_TKTenSV");
            dgv_danhsach.DataSource = ds.Tables["tbl_TKTenSV"];
        }

        //Xoa du lieu form
        private void XoaDuLieu()
        {
            txt_masv.Text = "";
            txt_tensv.Clear();
            txt_quequan.Clear();
            txt_malop.Clear();
        }

        //ham Them sinh vien
        private void ThemSinhVien()
        {
            try
            {
                MoKetNoi();

                DataRow rows = ds.Tables["tbl_SinhVien"].NewRow();

                rows["MaSV"] = txt_masv.Text.Trim();
                rows["TenSV"] = txt_tensv.Text.Trim();
                if (rad_nam.Checked == true)
                {
                    rows["GioiTinh"] = "Nam";
                }
                else if (rad_nu.Checked == true)
                {
                    rows["GioiTinh"] = "Nữ";
                }
                rows["NgaySinh"] = dtp_ngaysinh.Value.Month + "/" + dtp_ngaysinh.Value.Day + "/" + dtp_ngaysinh.Value.Year;
                rows["QueQuan"] = txt_quequan.Text.Trim();
                rows["MaLop"] = txt_malop.Text.Trim();

                ds.Tables["tbl_SinhVien"].Rows.Add(rows);
                int kq = adapter.Update(ds.Tables["tbl_SinhVien"]);
                if (kq > 0)
                {
                    HienThiDanhSach();
                    MessageBox.Show("Thêm sinh viên thành công!");
                    XoaDuLieu();
                }
                else
                {
                    HienThiDanhSach();
                    MessageBox.Show("Thêm sinh viên không thành công!");
                    XoaDuLieu();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi ở đây!!!",ex.Message);
            }
        }
        

        //Ham sua thong tin sinh vien
        private void SuaSinhVien()
        {
            MoKetNoi();
        }

        private void btn_thoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có thực sự muốn thoát?","Hộp thoại",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if(result == DialogResult.Yes) Close(); 
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            HienThiDanhSach();
     
            btn_sua.Enabled= false;
            btn_xoa.Enabled= false;
            grb_TTCT.Enabled= false;
        }

        private void btn_timkiem_Click(object sender, EventArgs e)
        {
            //lay du lieu
            string maSV = txt_TKmasv.Text.Trim();
            string tenSV = txt_TKtensv.Text.Trim();

            if (maSV != "" && tenSV == "")
            {
                TimKiemMaSV(maSV);
            }
            else if(maSV == "" && tenSV != "")
            {
                TimKiemTenSV(tenSV);
            }
            else if(maSV != "" && tenSV != "")
            {
                TimKiemMaSV(maSV);
            }
            else
            {
                MessageBox.Show("Bạn chưa nhập thông tin tìm kiếm!");
                txt_masv.Focus();
            }
        }

        int chucnang = 0;

        private void btn_luu_Click(object sender, EventArgs e)
        {
            if(chucnang == 1)
            {
                ThemSinhVien();
            }
            else if(chucnang == 2)
            {
                SuaSinhVien();
            }
        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            chucnang = 1;
            grb_TTCT.Enabled = true;
        }

        private void btn_sua_Click(object sender, EventArgs e)
        {
            chucnang = 2;
            grb_TTCT.Enabled = true;
        }
    }
}
