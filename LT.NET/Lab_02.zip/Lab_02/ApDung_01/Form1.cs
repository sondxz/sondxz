﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApDung_01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_thoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có thực sự muốn thoát?", "Hộp thoại", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btn_tim_Click(object sender, EventArgs e)
        {
            try
            {
                int a = Convert.ToInt32(txt_NhapA);
                int b = Convert.ToInt32(txt_NhapB);

                if (rad_uscln.Checked == true)
                {
                    txt_Kqua.Text = TimUSCLN(a, b).ToString();
                }
                else if (rad_bscln.Checked == true)
                {
                    txt_Kqua.Text = TimBSCLN(a, b).ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi ở đây:" + ex.ToString());
            }
        }
        private int TimUSCLN(int a, int b)
        {
            int r = a % b;
            while (r != 0)
            {
                a = b;
                b = r;
                r = a % b;
            }

            return b;
        }
        private int TimBSCLN(int a, int b)
        {

            return 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            rad_uscln.Checked= true;
        }

        
    }
}
