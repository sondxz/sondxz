﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ApDung_02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string pass;
        private void btn_1_Click(object sender, EventArgs e)
        {
            pass += "1";
            txt_pass.Text = pass;
        }

        private void btn_2_Click(object sender, EventArgs e)
        {
            pass += "2";
            txt_pass.Text = pass;
        }

        private void btn_3_Click(object sender, EventArgs e)
        {
            pass += "3";
            txt_pass.Text = pass;
        }

        private void btn_4_Click(object sender, EventArgs e)
        {
            pass += "4";
            txt_pass.Text = pass;
        }

        private void btn_5_Click(object sender, EventArgs e)
        {
            pass += "5";
            txt_pass.Text = pass;
        }

        private void btn_6_Click(object sender, EventArgs e)
        {
            pass += "6";
            txt_pass.Text = pass;
        }

        private void btn_7_Click(object sender, EventArgs e)
        {
            pass += "7";
            txt_pass.Text = pass;
        }

        private void btn_8_Click(object sender, EventArgs e)
        {
            pass += "8";
            txt_pass.Text = pass;
        }

        private void btn_9_Click(object sender, EventArgs e)
        {
            pass += "9";
            txt_pass.Text = pass;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txt_pass.Text = "";
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            txt_pass.Clear();
            pass= "";
        }

        private void btn_enter_Click(object sender, EventArgs e)
        {
            if (pass == "1496" || pass == "2673")
            {
                ListViewItem lvi = new ListViewItem(DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
                lvi.SubItems.Add("Phát triển công nghệ!");
                lvi.SubItems.Add("Chấp nhận");

                lst_log.Items.Add(lvi);
            }
            else if (pass == "7462" )
            {
                ListViewItem lvi = new ListViewItem(DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
                lvi.SubItems.Add("Nghiên cứu viên!");
                lvi.SubItems.Add("Chấp nhận");

                lst_log.Items.Add(lvi);
            }
            else if (pass == "8884" || pass == "3842" || pass == "3383")
            {
                ListViewItem lvi = new ListViewItem(DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
                lvi.SubItems.Add("Thiết kế mô hình!");
                lvi.SubItems.Add("Chấp nhận");

                lst_log.Items.Add(lvi);
            }
            else 
            {
                ListViewItem lvi = new ListViewItem(DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss"));
                lvi.SubItems.Add("Không có!");
                lvi.SubItems.Add("Không Chấp nhận");

                lst_log.Items.Add(lvi);
            }
        }
    }
}
