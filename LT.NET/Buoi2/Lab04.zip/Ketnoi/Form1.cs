﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ketnoi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //mo ket noi
        string strcon = @"Data Source=M09;Initial Catalog=QLSinhVien;Integrated Security=True";
        SqlConnection sqlcon = null;

        public void MoKetNoi()
        {
            if(sqlcon == null) { sqlcon = new SqlConnection(strcon); }
            if(sqlcon.State == ConnectionState.Closed) { sqlcon.Open(); }
        }

        public void DongKetNoi()
        {
            if(sqlcon != null && sqlcon.State == ConnectionState.Open ) 
            {
                sqlcon.Close();
            }
        }
        
        private void btn_knoi_Click(object sender, EventArgs e)
        {
            MoKetNoi();
            MessageBox.Show("Bạn kết nối thành công","Hộp thoại",MessageBoxButtons.OK,MessageBoxIcon.Information);
           
        }
    }
}
