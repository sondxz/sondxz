﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TruyVan1DuLieu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string strcon = @"Data Source=M09;Initial Catalog=QLSinhVien;Integrated Security=True";
        SqlConnection sqlcon = null;

        private void MoKetNoi()
        {
            if(sqlcon == null) { sqlcon = new SqlConnection(strcon); }
            if(sqlcon.State == ConnectionState.Closed) { sqlcon.Open(); }
        }

        private void DongKetNoi()
        {
            if(sqlcon != null && sqlcon.State == ConnectionState.Open)
            {
                sqlcon.Close();
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            MoKetNoi();

            SqlCommand sqlcmd = new SqlCommand();
            sqlcmd.CommandType = CommandType.Text;
            sqlcmd.CommandText = "select count(*) from SinhVien";
            sqlcmd.Connection = sqlcon;

            int kq = (int)sqlcmd.ExecuteScalar();

            MessageBox.Show("Số lượng sinh viên là: " + kq,"Hộp thại");
        }
    }
}
